


                          \    |    /
                     \                   /
     ---------===��>>      GROBBLINGS     <<��===---------
    |                                                     |
    |                         by                          |
    |                                                     |
    |       Henrik 'carnalizer' Pettersson (c)2014        |
    |                                                     |
    |_____________________________________________________|
                     /                   \
                          /    |    \



version 0.3

Grobblings live in closed eco systems in caves beneath the mountains. Grobblings take care of their cave, and will shape it to suit their needs. Still, they rely on you, their imaginary god-leader to show them where to use their ability to explode destructively, for a greater good. A good god-leader can increase the population much!


HOW TO PLAY:
Doubleclick Grobblings.bat to start. Click to place markers where you want grobblings to explode.



What is on screen:
Green stuff:	Grobbling. Or if darker and static; grobbling egg.
Gray stuff:	Rock, wall and floor.
Blue stuff:	Water. Essential.
Orange stuff:	Shrooms. Needs fertilizer.
Brown stuff:	Grobbling poop. Excellent fertilizer. Grobblings tidy their own cave.
Red stuff:	Your "explode-here"-marker.



Keyboard shortcuts:
c 	- show collisionMap.
w 	- show water potential field/ant trails.
f 	- show food potential field/ant trails.
h	- show map for where grobblings want to dig.
s	- save
l	- load
r	- restart
+	- increase game speed
-	- decrease game speed

Note:
To experiment you can edit the file collisionMap.png to make your own map. Save a backup though.
