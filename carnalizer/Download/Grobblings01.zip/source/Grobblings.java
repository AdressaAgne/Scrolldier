import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Grobblings extends PApplet {

/*   ---------===:::>>>>   RE-life
                            by Henrik 'carnalizer' Pettersson, (c)2013
*/

// GAME STATES *****************
final int STATE_SPLASH= 0;
final int STATE_MENU = 1;
final int STATE_GAME = 2;
final int STATE_PAUSED = 3;
int gameState = STATE_GAME;
final int WHITE = color(255,255,255);
final int BLACK = color(0,0,0);
final int GROBBLING = color(100,200,0);
final int POOP = color(120,70,50);
final int EGG = color(18,133,50);
final int SHROOM = color(250,100,50);
final int WATER = color(70,90,190);
final int BOMB = color(255,00,00);


int grobblingCounter=0;

boolean saved=true;
boolean showWaterTrail=false;
boolean showFoodTrail=false;
boolean showCollision=false;
//PImage collisionMap;
PImage collisionMap;
PImage waterMap;
PImage foodMap;
PImage background;
PImage buffer;
PImage multiSpriteMap;
PImage hole;
String outMessage="Go!";
int scrWidth=256, scrHeight=192;
boolean keyUp=false,keyDown=false,keyLeft=false,keyRight=false;
PFont font;
//Mob testMob= new Mob();
ArrayList mobs;
ArrayList anims;


public void setup(){
  randomSeed(0);
  noSmooth();
  anims = new ArrayList();
  font = loadFont("04b03-48.vlw");
  //collisionMap=loadImage("collisionMap.png");
  multiSpriteMap=loadImage("anims.png");
  buffer=loadImage("background.png");
  hole=loadImage("hole.png");
  collisionMap=loadImage("collisionMap.png");
  waterMap=loadImage("waterMap.png");
  foodMap=loadImage("foodMap.png");
  background=loadImage("background.png");
  textFont(font);
  textSize(8);
  textAlign(CENTER);
  size(scrWidth*4,scrHeight*4,JAVA2D);
  background(20,20,10);
  
  mobs = new ArrayList();
  makeMobs();
  
}

public void makeMobs(){
  for (int i = 0; i < 20; i++) {
    boolean lookingForSpot=true;
    float tryX=random(scrWidth*0.125f);//+random(scrWidth*0.125);
    float tryY=random(scrHeight*0.125f);//+random(scrHeight*0.125);
    while (lookingForSpot){
      tryX=random(scrWidth*0.17f)+random(scrWidth*0.17f);
      tryY=random(scrHeight*0.17f)+random(scrHeight*0.17f);
      if(collisionMap.get(PApplet.parseInt(tryX),PApplet.parseInt(tryY))==WHITE){
        lookingForSpot=false;
      }
    }
    mobs.add (new Mob(tryX,tryY,random(0.7f)));
  }
}


class Mob { 
  float X,Y,lookAtX,lookAtY,targetX,targetY,timer,delay;
  float health,age,food,water,stomach;
  boolean kill;
  boolean carriesPoop;
  boolean carriesEgg;
  int need;
  
  
  Mob(float startX,float startY,float _age) {
    X = startX;
    Y = startY;
    targetX=random(X-300,X+300);
    targetY=random(Y-300,Y+300);
    lookAtX = X;
    lookAtY = Y;
    delay=25;
    timer=millis()+ random(delay);
    age=_age;
    health=0.5f+random(0.5f);
    food=random(1);
    water=random(0.7f);
    stomach=random(0.5f);
    need=0;
    carriesPoop=false;
    kill = false;
  } 
  public void update() {
    if(timer+delay<millis()){
      delay=10+random(10)+((1.05f-health)*100);
      timer=millis();
      status();
      if(!kill){
        switch (need){
          case 0:
            randomTarget();
            break;
          case 1:
            foodTarget();
            break;
          case 2:
            waterTarget();
            break;
          default:
          break;
        }
        moveByTarget();
      }
    }
  }
  
  public void status(){
    age+=0.001f;
    food-=0.0005f;
    if(random(1)<0.1f){water-=0.005f;}
    
    if(health<0){
      killMe();
    }
    
    if(food<0.1f){
      need=1;
      int _trail = adjustColor(foodMap.get(PApplet.parseInt(X),PApplet.parseInt(Y)),-1,-1,-1);
      foodMap.set(PApplet.parseInt(X),PApplet.parseInt(Y), _trail );
      //println("hungry!");
      if(food<0){health-=0.01f;}
    }else{
      int _trail = adjustColor(foodMap.get(PApplet.parseInt(X),PApplet.parseInt(Y)),PApplet.parseInt(food*2.0f),PApplet.parseInt(food*2.0f),PApplet.parseInt(food*2.0f));
      foodMap.set(PApplet.parseInt(X),PApplet.parseInt(Y), _trail );
    }
    if(stomach > 0.4f){
      int _trail = adjustColor(foodMap.get(PApplet.parseInt(X),PApplet.parseInt(Y)),PApplet.parseInt(food*2.0f),PApplet.parseInt(food*2.0f),PApplet.parseInt(food*2.0f));
      foodMap.set(PApplet.parseInt(X),PApplet.parseInt(Y), _trail );
    }
    
    if(water<0.2f){
      //println("thirsty!");
      need=2;
      int _trail = adjustColor(waterMap.get(PApplet.parseInt(X),PApplet.parseInt(Y)),-1,-1,-1);
      waterMap.set(PApplet.parseInt(X),PApplet.parseInt(Y), _trail );
      if(water<0){health-=0.01f;}
    }else{
      int _trail = adjustColor(waterMap.get(PApplet.parseInt(X),PApplet.parseInt(Y)),PApplet.parseInt(water*5),PApplet.parseInt(water*5),PApplet.parseInt(water*5));
      waterMap.set(PApplet.parseInt(X),PApplet.parseInt(Y), _trail );
    }
    
    if(food>0.2f && water>0.2f){
      need=0;
    }
    
    if(age>1){
      health-=0.01f;
    }
  }
  
  public void moveByTarget(){
    float xDiff = X-targetX;
    float yDiff = Y-targetY;
    float xR = abs(xDiff)/(abs(xDiff)+abs(yDiff));
    float yR = abs(yDiff)/(abs(xDiff)+abs(yDiff));
    
    if(random(1)<xR){
      lookAtX = (xDiff < 0) ? X+1:X-1;
    }
    if(random(1)<yR){
      lookAtY = (yDiff < 0) ? Y+1:Y-1;
    }
    if( inBounds(PApplet.parseInt(lookAtX),PApplet.parseInt(lookAtY)) ){
      if(collisionMap.get(PApplet.parseInt(lookAtX),PApplet.parseInt(lookAtY))== WHITE){
        collisionMap.set(PApplet.parseInt(lookAtX),PApplet.parseInt(lookAtY),GROBBLING);
        collisionMap.set(PApplet.parseInt(X),PApplet.parseInt(Y),WHITE);
        /*
        if(random(1)<0.01 && food > 0.8){
          collisionMap.set(int(X),int(Y),POOP);
        }
        */
        X=lookAtX;
        Y=lookAtY;
      }else{
        if(collisionMap.get(PApplet.parseInt(lookAtX),PApplet.parseInt(lookAtY))== WATER){
          water=1;
        }
        if(collisionMap.get(PApplet.parseInt(lookAtX),PApplet.parseInt(lookAtY))== GROBBLING){
          if(water>0.7f && food >0.7f && age >0.5f && health > 0.6f && brightness(waterMap.get(PApplet.parseInt(X),PApplet.parseInt(Y))) < 100){
            int _x = PApplet.parseInt(random(-2,2));
            int _y = PApplet.parseInt(random(-2,2));
            if(collisionMap.get(PApplet.parseInt(X+_x),PApplet.parseInt(Y+_y))==WHITE){
              //println("make baby grobbling!");
              health-=0.1f;
              collisionMap.set(PApplet.parseInt(X+_x),PApplet.parseInt(Y+_y),EGG);
            }
          }
        }
        if(collisionMap.get(PApplet.parseInt(lookAtX),PApplet.parseInt(lookAtY))== SHROOM && food < 0.5f){
          food=1;
          stomach=1;
          collisionMap.set(PApplet.parseInt(lookAtX),PApplet.parseInt(lookAtY),WHITE);
        }
        /*
        if(collisionMap.get(int(lookAtX),int(lookAtY))== EGG && !carriesEgg){
          carriesEgg=true;
          collisionMap.set(int(lookAtX),int(lookAtY),WHITE);
        }*/
        if(carriesEgg){
          if(collisionMap.get(PApplet.parseInt(lookAtX),PApplet.parseInt(lookAtY))== EGG || collisionMap.get(PApplet.parseInt(lookAtX),PApplet.parseInt(lookAtY))== BLACK){
            carriesEgg=false;
            collisionMap.set(PApplet.parseInt(X),PApplet.parseInt(Y),EGG);
          }
        }
        if(collisionMap.get(PApplet.parseInt(lookAtX),PApplet.parseInt(lookAtY))== BLACK || collisionMap.get(PApplet.parseInt(lookAtX),PApplet.parseInt(lookAtY))== POOP){
          if(stomach>0.3f){
            stomach-=0.4f;
            collisionMap.set(PApplet.parseInt(X),PApplet.parseInt(Y),POOP);
          }
        }
        if(collisionMap.get(PApplet.parseInt(lookAtX),PApplet.parseInt(lookAtY))== BOMB){
          killMe();
          anims.add(new multiAnimObject(multiSpriteMap, 16, 16, PApplet.parseInt(X-8),PApplet.parseInt(Y-8), 0.2f, 0));
          //println(int(X-8));
          for(int _g=mobs.size()-1;_g>=0;_g--){
            Mob _m = (Mob) mobs.get(_g);
            if(distance(_m.X,_m.Y,X,Y)<50){
              _m.killMe();
            }
          }
          for(int _y=0;_y<hole.height;_y++){
            for(int _x=0;_x<hole.width;_x++){
              if(hole.get(_x,_y)==WHITE){
                //println(_x);
                collisionMap.set(PApplet.parseInt(X-8)+_x, PApplet.parseInt(Y-8)+_y, WHITE);
              }
            }
          }
          //collisionMap.copy(hole, 0, 0, 16, 16, int(X)-8, int(Y)-8, int(X)+8, int(Y)+8);
        }
        if(collisionMap.get(PApplet.parseInt(lookAtX),PApplet.parseInt(lookAtY))== POOP && !carriesPoop){
          //println("poop!");
          carriesPoop=true;
          collisionMap.set(PApplet.parseInt(lookAtX),PApplet.parseInt(lookAtY),WHITE);
        }
        if(carriesPoop){
          if(collisionMap.get(PApplet.parseInt(lookAtX),PApplet.parseInt(lookAtY))== POOP || collisionMap.get(PApplet.parseInt(lookAtX),PApplet.parseInt(lookAtY))== SHROOM || collisionMap.get(PApplet.parseInt(lookAtX),PApplet.parseInt(lookAtY))== BLACK){
            //println("more poop!");
            carriesPoop=false;
            collisionMap.set(PApplet.parseInt(X),PApplet.parseInt(Y),POOP);
          }
        }
        if(!kill){
          lookAtX=X+PApplet.parseInt(random(-2,2));
          lookAtY=Y+PApplet.parseInt(random(-2,2));
          if( inBounds(PApplet.parseInt(lookAtX),PApplet.parseInt(lookAtY)) ){
            if(collisionMap.get(PApplet.parseInt(lookAtX),PApplet.parseInt(lookAtY))== WHITE){
              collisionMap.set(PApplet.parseInt(lookAtX),PApplet.parseInt(lookAtY),GROBBLING);
              if(collisionMap.get(PApplet.parseInt(X),PApplet.parseInt(Y))==POOP){
                //collisionMap.set(int(X),int(Y),POOP);
              }else{
                collisionMap.set(PApplet.parseInt(X),PApplet.parseInt(Y),WHITE);
              }
              targetX=random(X-300,X+300);
              targetY=random(Y-300,Y+300);
              X=lookAtX;
              Y=lookAtY;
            }
          }
        }
      }
    }
  }
  public void killMe(){
    println("dies at age:",age,"water:",water,"food:",food,"health:",health);
    collisionMap.set(PApplet.parseInt(X),PApplet.parseInt(Y),WHITE);
    kill=true;
  }
  public void randomTarget(){
  }
  public void foodTarget(){
    int _x = PApplet.parseInt(random(-5,5));
    int _y = PApplet.parseInt(random(-5,5));
    boolean _success = false;
    int _compare=foodMap.get(PApplet.parseInt(X),PApplet.parseInt(Y));
    for(int _i=0;_i<15;_i++){
      if(inBounds(PApplet.parseInt(X+_x),PApplet.parseInt(Y+_y)) && !_success){
        if( foodMap.get(PApplet.parseInt(_x+X),PApplet.parseInt(_y+Y)) > _compare ){
          _compare=foodMap.get(PApplet.parseInt(_x+X),PApplet.parseInt(_y+Y));
          targetX=_x+X;
          targetY=_y+Y;
           _x = PApplet.parseInt(random(-5,5));
           _y = PApplet.parseInt(random(-5,5));
          if(collisionMap.get(PApplet.parseInt(_x+X),PApplet.parseInt(_y+Y)) == SHROOM){
            targetX=_x+X;
            targetY=_y+Y;
            _success=true;
          }
        }
      }
    }
    /*
    for(int _i=0;_i<60;_i++){
      int _x = int(random(-15,15));
      int _y = int(random(-15,15));
      if(inBounds(int(X+_x),int(Y+_y))){
        if(collisionMap.get(int(X+_x),int(Y+_y)) == SHROOM){
          targetX=_x+X;
          targetY=_y+Y;
        }
      }
    }*/
  }
  public void waterTarget(){
    int _x = PApplet.parseInt(random(-5,5));
    int _y = PApplet.parseInt(random(-5,5));
    boolean _success = false;
    int _compare=waterMap.get(PApplet.parseInt(X),PApplet.parseInt(Y));
    for(int _i=0;_i<15;_i++){
      if(inBounds(PApplet.parseInt(X+_x),PApplet.parseInt(Y+_y)) && !_success){
        if( waterMap.get(PApplet.parseInt(_x+X),PApplet.parseInt(_y+Y)) > _compare ){
          _compare=waterMap.get(PApplet.parseInt(_x+X),PApplet.parseInt(_y+Y));
          targetX=_x+X;
          targetY=_y+Y;
          _x = PApplet.parseInt(random(-5,5));
           _y = PApplet.parseInt(random(-5,5));
          if(collisionMap.get(PApplet.parseInt(_x+X),PApplet.parseInt(_y+Y)) == WATER){
            targetX=_x+X;
            targetY=_y+Y;
            _success=true;
          }
        }
      }
    }
  }
} 

class multiAnimObject {
  PImage spriteMap;
  PImage[][] images;
  float currentFrame, currentAnimation;
  float frame,animation;
  float pace;
  int xpos;
  int ypos;
  boolean finished = false;
  
  multiAnimObject(PImage sprMap, int sprWidth, int sprHeight, int mx, int my, float p, int _anim) { // initialize a new object. Why is the double initialization done? Compare count->imageCount to sprWidth is only sprWidth.
    spriteMap = sprMap;
    xpos = mx;
    ypos = my;
    pace = p;

    animation = spriteMap.height/sprHeight;
    frame = spriteMap.width/sprWidth;
    images = new PImage[PApplet.parseInt(animation)][PApplet.parseInt(frame)];
    currentFrame=0;
    currentAnimation=_anim;
    for (int a = 0; a < animation; a++) {
      for (int i = 0; i < frame; i++) {
        //println("a: "+ a + ", i: " + i);
        images[a][i] = createImage(sprWidth, sprHeight, ARGB);
        images[a][i].copy(spriteMap,i*sprWidth,a*sprHeight,sprWidth,sprHeight,0,0,sprWidth,sprHeight); 
      }
    }
  }
  
  public multiAnimObject setDelay(float delay) {
    currentFrame = -delay;
    return this;
  }

  public void display(float xpos, float ypos) {
    currentFrame = (currentFrame+pace);
    if (PApplet.parseInt(currentFrame) >= frame){
      finished=true;
    } else {
      if (currentFrame < 0) {
        return;
      }
      image(images[PApplet.parseInt(currentAnimation)][PApplet.parseInt(currentFrame)], xpos, ypos);
    }
  }
}
public boolean inBounds(int xx, int yy){
  return (xx>=0 && yy>=0 && xx<scrWidth && yy<scrHeight);
}

public float distance(float x1, float y1, float x2, float y2){
  float dis = abs((x1 - x2)*(x1 - x2) + (y1 - y2)*(y1 - y2));
  return dis;
}

public int adjustColor(int _in,int _r,int _g,int _b){
  int _newColor = color(red(_in)+_r,green(_in)+_g,blue(_in)+_b);
  return _newColor;
}

public void plantShrooms(){
  for (int _i=0;_i<200;_i++){
    int _x=PApplet.parseInt(random(scrWidth));
    int _y=PApplet.parseInt(random(scrHeight));
    if(collisionMap.get(_x,_y)==POOP){
      int _x2=PApplet.parseInt(random(-3,3));
      int _y2=PApplet.parseInt(random(-3,3));
      if(inBounds(_x+_x2,_y+_y2)){
        if(collisionMap.get(_x+_x2,_y+_y2)==WHITE){
          collisionMap.set(_x+_x2,_y+_y2,SHROOM);
          collisionMap.set(_x,_y,WHITE);
        }
      }
    }
  }
}
public void hatchEggs(){
  for (int _i=0;_i<40;_i++){
    int _x=PApplet.parseInt(random(scrWidth));
    int _y=PApplet.parseInt(random(scrHeight));
    if(collisionMap.get(_x,_y)==EGG){
      collisionMap.set(_x,_y,GROBBLING);
      mobs.add (new Mob(_x,_y,0));
    }
  }
}

public void updatePotentialFields(){
  for (int _i=0;_i<250;_i++){
    int _x=PApplet.parseInt(random(scrWidth));
    int _y=PApplet.parseInt(random(scrHeight));
    
    if(collisionMap.get(_x,_y)==WATER){
      waterMap.set(_x,_y,WHITE);
    }else{
      int _avg = PApplet.parseInt(averagePixel(_x, _y, waterMap));
      waterMap.set( _x,_y, color(_avg));
    }
    if(collisionMap.get(_x,_y)==BLACK){
      waterMap.set(_x,_y,BLACK);
    }
    /*
    _x=int(random(scrWidth));
    _y=int(random(scrHeight));
    
    if(collisionMap.get(_x,_y)==SHROOM){
      waterMap.set(_x,_y,WHITE);
    }else{
      int _avg = int(averagePixel(_x, _y, foodMap));
      foodMap.set( _x,_y, color(_avg));
    }
    
    if(collisionMap.get(_x,_y)==BLACK && random(1)<0.3){
      foodMap.set(_x,_y,BLACK);
    }*/
    /*
    if(random(1)<0.00001){
      waterMap.loadPixels();
      //for(int _i=0;_i<
      
      //loadPixels();
      for (int i = 0; i < scrWidth*scrHeight; i++) {
       waterMap.pixels[i] =adjustColor(waterMap.pixels[i],-1,-1,-1);
      }
      waterMap.updatePixels();

    }
    */
  }
}

public float averagePixel(int xx, int yy, PImage _img){
  float count=0;
  int _c;
  for(int tx = -1;tx<2;tx++){
    for(int ty = -1;ty<2;ty++){
      if(inBounds(xx+tx,yy+ty)){
        if (tx==0 && ty==0){
          //_c=color(0);
          _c=_img.get(xx+tx,yy+ty);
        }else{
          _c=_img.get(xx+tx,yy+ty);
        }
        
      }else{
        _c=color(0);
      }
      count+=brightness(_c);
      
    }
  }
  return count/9;
}


public int countSurrounding(int xx, int yy, int compareWith, PImage _img){
  int count=0;
  for(int tx = -1;tx<2;tx++){
    for(int ty = -1;ty<2;ty++){
      if(inBounds(xx+tx,yy+ty)){
        if(_img.get((xx+tx),(yy+ty)) == compareWith){
          if (tx==0 && ty==0){
            //FUGDE
          }else{
            count++;
          }
        }
        
      }
    }
  }
  return count;
}

public void keyPressed() {
  if(gameState==STATE_SPLASH || gameState==STATE_PAUSED){
    gameState=STATE_GAME;
    //println(gameState);
  }
  if (key == 'w' || key == 'W'){
    showWaterTrail = (showWaterTrail) ? false : true ;
  }
  if (key == 'f' || key == 'F'){
    showFoodTrail = (showFoodTrail) ? false : true ;
  }
  if (key == 'c' || key == 'C'){
    showCollision = (showCollision) ? false : true ;
  }
  if (key == 'p' || key == 'P') {
    gameState=STATE_PAUSED;
  }
  if (keyCode == UP){
    keyUp=true;
  }
  if (keyCode == DOWN){
    keyDown=true;
  }
  if (keyCode == LEFT){
    keyLeft=true;
  }
  if (keyCode == RIGHT){
    keyRight=true;
  }
  if(keyUp){print("U");}
  if(keyDown){print("D");}
  if(keyLeft){print("L");}
  if(keyRight){print("R");}
}

public void keyReleased() {  
  if (key == 'p' || key == 'P') {

  }
  if (keyCode == UP){
    keyUp=false;
  }
  if (keyCode == DOWN){
    keyDown=false;
  }
  if (keyCode == LEFT){
    keyLeft=false;
  }
  if (keyCode == RIGHT){
    keyRight=false;
  }
}


public void mouseClicked() {
  if(gameState==STATE_SPLASH || gameState==STATE_PAUSED){
    gameState=STATE_GAME;
    //println(gameState);
  }
}

public void draw(){
  tick();
  render();
}

public void tick(){
  switch (gameState){
    case STATE_SPLASH:
      splash();
    break;
    case STATE_MENU:
    break;
    case STATE_GAME:
      tickGame();
    break;
    case STATE_PAUSED:
    break;
    default:
    break;
  }
}

public void render(){
  background(40,30,20);
  scale(4.0f);
    switch (gameState){
    case STATE_SPLASH:
      splash();
    break;
    case STATE_MENU:
    break;
    case STATE_GAME:
      renderGame();
    break;
    case STATE_PAUSED:
    break;
    default:
    break;
  }
}
public void renderGame(){
  //image(background,0,0);
  buffer.copy(background,0,0,scrWidth,scrHeight,0,0,scrWidth,scrHeight);
  //buffer.copy(background);
  int _tColor;
  for(int _y=0;_y<scrWidth;_y++){
    for(int _x=0;_x<scrWidth;_x++){
      _tColor = collisionMap.get(_x,_y);
      if(_tColor == WHITE){
        buffer.set(_x,_y,adjustColor(background.get(_x,_y),-50,-45,-40));
      }
      if(_tColor == WATER){
        buffer.set(_x,_y,adjustColor(background.get(_x,_y),-30,-25,+40));
      }
      if(_tColor == SHROOM){
        buffer.set(_x,_y,SHROOM);
      }
      if(_tColor == BOMB){
        buffer.set(_x,_y,BOMB);
      }
      if(_tColor == EGG){
        buffer.set(_x,_y,EGG);
      }
      if(_tColor == POOP){
        buffer.set(_x,_y,POOP);
      }
      if(_tColor == BLACK && collisionMap.get(_x,_y+1)==WHITE){
        buffer.set(_x,_y,adjustColor(background.get(_x,_y),+50,+40,0));
      }
      if(collisionMap.get(_x,_y)==GROBBLING){
        buffer.set(_x,_y,adjustColor(GROBBLING,-80,-70,-40));
        buffer.set(_x,_y-1,adjustColor(GROBBLING,10,-20,10));
      }
    }
  }
  image(buffer,0,0);
  if(showWaterTrail){image(waterMap,0,0);}
  if(showFoodTrail){image(foodMap,0,0);}
  if(showCollision){image(collisionMap,0,0);}
  //text(brightness(waterMap.get(int(mouseX*.25),int(mouseY*.25))),10,10);
  text("GROBBLINGS: " + grobblingCounter,scrWidth*0.5f,10);
  
  
  for (int i = anims.size()-1; i >= 0; i--) { // go through all the anims
    multiAnimObject _anim = (multiAnimObject) anims.get(i);
    _anim.display(_anim.xpos,_anim.ypos);
    
    if (_anim.finished) { // Items can be deleted with remove() from ArrayList.
      anims.remove(i);
    }
  }
  //tint(255,20);
  //image(collisionMap,0,0);
  //image(collisionMap,0,-1);
}
public void splash(){
  textAlign(CENTER);
  text("------**** GROBBLINGS ****------",scrWidth*0.5f,scrHeight*0.4f);
  text("PRESS SPACE",scrWidth*0.5f,scrHeight*0.6f);
}
public void tickGame(){
  for (int i = mobs.size()-1; i >= 0; i--) { // go through all the objects in the ArrayList
    Mob mobu = (Mob) mobs.get(i);
    if(mobu.kill){
      mobs.remove(i);
    }
    mobu.update();
  }
  grobblingCounter=mobs.size();
  updatePotentialFields();
  plantShrooms();
  hatchEggs();
  if(mousePressed){
    if(collisionMap.get(PApplet.parseInt(mouseX*0.25f),PApplet.parseInt(mouseY*0.25f)) != BLACK ){
      collisionMap.set(PApplet.parseInt(mouseX*0.25f),PApplet.parseInt(mouseY*0.25f),BOMB);
    }
  }
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Grobblings" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
