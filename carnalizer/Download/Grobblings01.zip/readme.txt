


                          \    |    /
                     \                   /
     ---------===��>>      GROBBLINGS     <<��===---------
    |                                                     |
    |                         by                          |
    |                                                     |
    |       Henrik 'carnalizer' Pettersson (c)2014        |
    |                                                     |
    |_____________________________________________________|
                     /                   \
                          /    |    \





Grobblings live in closed eco systems in caves beneath the mountains. They rely on you, their imaginary god-leader to show them where to use their ability to explode destructively. A good god-leader can increase the population much.


HOW TO PLAY:
click to place markers where you want grobblings to explode.



What is on screen:
Gray stuff:	Rock, wall and floor.
Blue stuff:	Water. Essential.
Orange stuff:	Shrooms. Needs fertilizer.
Brown stuff:	Grobbling poop. Excellent fertilizer. Grobblings tidy their own cave.
Red stuff:	Your "explode-here"-marker.



Keyboard shortcuts:
c 	- show collisionMap
w 	- show water potential field/ant trails
f 	- show food potential field/ant trails